from django.urls import path
from . import views

urlpatterns = [
    # Aquí irán las URLs relacionadas con pedidos
    # Por ejemplo:
    # path('', views.lista_pedidos, name='lista_pedidos'),
    # path('crear/', views.crear_pedido, name='crear_pedido'),
    # path('<int:pedido_id>/', views.detalle_pedido, name='detalle_pedido'),
]
